#!/usr/bin/env python3
from __future__ import annotations

import argparse
import importlib
import sys
from pathlib import Path
from typing import Optional, List

__version__ = "1.1b"

def _is_readable_file(p: Path) -> bool:
    try:
        return p.exists() and p.is_file()
    except Exception:
        return False

def _first_existing(candidates: List[Path]):
    for p in candidates:
        if _is_readable_file(p):
            return p
    return None

def detect_rice_paths(project_root: Path):
    base = project_root / "refGenome" / "rice"
    if not base.exists():
        return None, None
    chrom = _first_existing([
        base / "chrom.sizes",
        base / "rice.chrom.sizes",
        *list(base.glob("*.chrom.sizes"))
    ])
    gtf = _first_existing([
        base / "genes.gtf",
        base / "rice.gtf",
        *list(base.glob("*.gtf")),
        *list(base.glob("*.gtf.gz"))
    ])
    return (str(chrom) if chrom else None, str(gtf) if gtf else None)

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Wrapper for bin/IntegQC.py with optional HTML report generation."
    )
    p.add_argument("-i", "--input", type=str, required=False, default=None,
                   help="Input base directory; assigned to logic base_dir/BASE_DIR.")
    p.add_argument("-o", "--out", type=str, required=False, default=None,
                   help="Output directory; assigned to logic out_dir/OUT_DIR. Default: ./QC_results")
    p.add_argument("-s", "--species", type=str, choices=["rice"], required=False,
                   default=None, help="Species key for auto-detect. Currently supports 'rice'.")
    p.add_argument("-mrs", "--max-recorded-size", type=int, default=None,
                   help="Upper bound for fragment-size histogram.")
    p.add_argument("-sl", "--subsample-lines", type=int, default=None,
                   help="Subsample number of lines for fast preview.")
    p.add_argument("-grid", "--grid-rows", type=int, default=None,
                   help="Grid rows for plots.")
    p.add_argument("-dpi", "--dpi", type=int, default=None,
                   help="Figure DPI.")
    p.add_argument("-j", "--n-jobs", type=int, default=None,
                   help="Parallel workers for per-sample tasks.")
    p.add_argument("--make-html", action="store_true", default=True,
                   help="Generate qc_summary.html and QC_reports/ inside the QC_results folder.")
    p.add_argument("--html-title", type=str, default=None,
                   help="Custom HTML title for qc_summary.html (default: 'QC Summary').")
    p.add_argument("--embed-assets", action="store_true",
                   help="Embed JS/CSS into qc_summary.html for single-file distribution.")
    return p

def main(argv: Optional[list] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    project_root = Path(__file__).resolve().parent
    if str(project_root) not in sys.path:
        sys.path.insert(0, str(project_root))

    try:
        logic = importlib.import_module("bin.IntegQC")
    except Exception as e:
        print(f"[ERROR] Could not import 'bin.IntegQC': {e}", file=sys.stderr)
        return 1

    # inject base/out dirs
    if args.input:
        for name in ["base_dir", "BASE_DIR"]:
            setattr(logic, name, args.input)
    out_dir = args.out or None
    if out_dir:
        for name in ["out_dir", "OUT_DIR"]:
            setattr(logic, name, out_dir)

    if args.species == "rice":
        chrom_str, gtf_str = detect_rice_paths(project_root)
        if chrom_str:
            for name in ["CHROM_SIZES_PATH", "chrom_sizes_path"]:
                setattr(logic, name, chrom_str)
        if gtf_str:
            for name in ["GTF_PATH", "annot_path"]:
                setattr(logic, name, gtf_str)

    if args.max_recorded_size is not None:
        logic.max_recorded_size = int(args.max_recorded_size)
    if args.subsample_lines is not None:
        logic.subsample_lines = int(args.subsample_lines)
    if args.grid_rows is not None:
        logic.grid_rows = int(args.grid_rows)
    if args.dpi is not None:
        logic.dpi_save = int(args.dpi)
    if args.n_jobs is not None:
        logic.n_jobs = int(args.n_jobs)

    ran = False
    if hasattr(logic, "main") and callable(logic.main):
        try:
            logic.main()
            ran = True
        except Exception as e:
            print(f"[WARN] logic.main() failed: {e}", file=sys.stderr)

    if not ran and hasattr(logic, "run_pipeline") and callable(logic.run_pipeline):
        try:
            logic.run_pipeline()
            ran = True
        except Exception as e:
            print(f"[WARN] run_pipeline invocation failed: {e}", file=sys.stderr)

    if args.make_html:
        try:
            from bin import makeQCReport as report
            used_out = getattr(logic, "out_dir", None) or getattr(logic, "OUT_DIR", None)
            if used_out is None:
                used_out = str(Path.cwd() / "QC_results")
            report.build_html_report(
                out_dir=used_out,
                html_title=args.html_title or "QC Summary",
                embed_assets=args.embed_assets
            )
            print(f"[OK] HTML report generated at: {Path(used_out) / 'qc_summary.html'}")
        except Exception as e:
            print(f"[WARN] HTML report generation failed: {e}", file=sys.stderr)

    print("[OK] Finished.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
